# Application PetClinic

## This application uses Spring Boot 

## v1.0.0 --> Version with unit test
